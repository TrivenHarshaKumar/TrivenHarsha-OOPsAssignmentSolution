package driver;

import departments.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AdminDepartment AdmDeptObj = new AdminDepartment();
		HrDepartment HrDeptObj = new HrDepartment();
		TechDepartment TechDeptObj = new TechDepartment();
		
		System.out.println(" Welcome to "+AdmDeptObj.departmentName());
		System.out.println(AdmDeptObj.getTodaysWork());
		System.out.println(AdmDeptObj.getWorkDeadline());
		System.out.println(AdmDeptObj.isTodayAHoliday());
		System.out.println();
		System.out.println(" Welcome to "+HrDeptObj.departmentName());
		System.out.println(HrDeptObj.doActivity());
		System.out.println(HrDeptObj.getTodaysWork());
		System.out.println(HrDeptObj.getWorkDeadline());
		System.out.println(HrDeptObj.isTodayAHoliday());
		System.out.println("\n");
		System.out.println(" Welcome to "+TechDeptObj.departmentName());
		System.out.println(TechDeptObj.getTodaysWork());
		System.out.println(TechDeptObj.getWorkDeadline());
		System.out.println(TechDeptObj.getTechStackInformation());
		System.out.println(TechDeptObj.isTodayAHoliday());
	}

}
